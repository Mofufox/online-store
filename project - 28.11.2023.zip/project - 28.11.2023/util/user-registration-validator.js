const userCredentialsAreInvalid = (email, password) => {
  return (
    !email || !email.includes('@') || !password || !password.trim().length >= 6
  );
};

const userInputFieldIsInvalid = (value) => {
  return !value || value.trim() === '';
};

const userRegistrationDetailsAreValid = (
  email,
  password,
  fullname,
  street,
  postal,
  city
) => {
  return (
    !userCredentialsAreInvalid(email, password) &&
    !userInputFieldIsInvalid(fullname) &&
    !userInputFieldIsInvalid(street) &&
    !userInputFieldIsInvalid(postal) &&
    !userInputFieldIsInvalid(city)
  );
};

const userEmailIsConfirmed = (email, confirmedEmail) => {
  return email === confirmedEmail;
};

module.exports = {
  userRegistrationDetailsAreValid: userRegistrationDetailsAreValid,
  userEmailIsConfirmed: userEmailIsConfirmed,
};