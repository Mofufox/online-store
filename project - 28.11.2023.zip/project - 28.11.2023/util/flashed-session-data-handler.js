const getFlashedSessionData = (req) => {
  const flashedSessionData = req.session.flashedSessionData;

  req.session.flashedSessionData = null;

  return flashedSessionData;
};

const flashDataToSession = (req, data, action) => {
  req.session.flashedSessionData = data;
  req.session.save(action);
};

module.exports = {
  getFlashedSessionData: getFlashedSessionData,
  flashDataToSession: flashDataToSession,
};