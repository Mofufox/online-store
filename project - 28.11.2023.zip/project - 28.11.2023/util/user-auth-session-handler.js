const createUserSession = (req, user, action) => {
  req.session.uid = user._id.toString();
  req.session.isAdmin = user.isAdmin;
  req.session.save(action);
};

const destroyUserAuthSession = (req) => {
  req.session.uid = null;
};

module.exports = {
  createUserAuthSession: createUserSession,
  destroyUserAuthSession: destroyUserAuthSession,
};

// A kód alapján, amit megosztottál, úgy tűnik, 
// hogy a fájl funkciói a felhasználói munkamenetek létrehozásával 
// és megszüntetésével kapcsolatosak. 
// Ezért a `user-session-handler.js` vagy `user-auth-session.js` 
// nevek talán jobban tükrözik a fájl tartalmát. 
// Az `authentication.js` név is megfelelő lehet, 
// ha a fájl további hitelesítési funkciókat is tartalmaz. 
// A `user-auth-session-handler.js` név talán 
// túl hosszú és bonyolult lehet. 
// A legjobb név választása mindig attól függ, 
// hogy a kód milyen kontextusban és milyen környezetben kerül 
// használatra.