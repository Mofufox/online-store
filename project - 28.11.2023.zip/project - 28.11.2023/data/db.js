const mongodb = require('mongodb');

const MongoClient = mongodb.MongoClient;

let db;

const connectToDb = async () => {
  const client = await MongoClient.connect('mongodb://127.0.0.1:27017');
  db = client.db('online-shop');
};

const getDb = () => {
  if (!db) {
    throw new Error('You must connect to the database first!');
  }

  return db;
};

module.exports = {
  connectToDb: connectToDb,
  getDb: getDb,
};
