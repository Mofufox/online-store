const Csrf = require('csrf');
const csrf = new Csrf();

const generateCsrfToken = (req, res, next) => {
  req.csrfToken = () => {
    const secret = req.session.csrfSecret || csrf.secretSync();
    req.session.csrfSecret = secret;
    return csrf.create(secret);
  };
  next();
};

module.exports = generateCsrfToken;
