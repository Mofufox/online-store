const User = require('../models/user.model');
const userAuthSessionHandlerUtil = require('../util/user-auth-session-handler');
const userRegistrationValidatorUtil = require('../util/user-registration-validator');
const flashedSessionDataHandlerUtil = require('../util/flashed-session-data-handler');

const getSignup = (req, res) => {
  let flashedSessionData =
    flashedSessionDataHandlerUtil.getFlashedSessionData(req);

  if (!flashedSessionData) {
    flashedSessionData = {
      email: '',
      confirmEmail: '',
      password: '',
      fullname: '',
      street: '',
      postal: '',
      city: '',
    };
  }
  res.render('customer/auth/signup', { inputData: flashedSessionData });
};

const signup = async (req, res, next) => {
  const enteredRegistrationData = {
    email: req.body.email,
    confirmEmail: req.body['confirm-email'],
    password: req.body.password,
    fullname: req.body.fullname,
    street: req.body.street,
    postal: req.body.postal,
    city: req.body.city,
  };

  if (
    !userRegistrationValidatorUtil.userRegistrationDetailsAreValid(
      req.body.email,
      req.body.password,
      req.body.fullname,
      req.body.street,
      req.body.postal,
      req.body.city
    ) ||
    !userRegistrationValidatorUtil.userEmailIsConfirmed(
      req.body.email,
      req.body['confirm-email']
    )
  ) {
    flashedSessionDataHandlerUtil.flashDataToSession(
      req,
      {
        errorMessage:
          'Please check your input. Password must be at least 6 characters long. Postal Code must be 5 characters long!',
        ...enteredRegistrationData,
      },
      () => {
        res.redirect('/signup');
      }
    );
    return;
  }

  const user = new User(
    req.body.email,
    req.body.password,
    req.body.fullname,
    req.body.street,
    req.body.postal,
    req.body.city
  );

  try {
    const userAlreadyExists = await user.userAlreadyExists();

    if (userAlreadyExists) {
      flashedSessionDataHandlerUtil.flashDataToSession(
        req,
        {
          errorMessage: 'User already exists! Try signing up instead!',
          ...enteredRegistrationData,
        },
        () => {
          res.redirect('/signup');
        }
      );
      return;
    }

    await user.signup();
  } catch (error) {
    next(error);
    return;
  }

  res.redirect('/login');
};

const getLogin = (req, res) => {
  let flashedSessionData =
    flashedSessionDataHandlerUtil.getFlashedSessionData(req);

  if (!flashedSessionData) {
    flashedSessionData = {
      email: '',
      password: '',
    };
  }
  res.render('customer/auth/login', { inputData: flashedSessionData });
};

const login = async (req, res, next) => {
  const user = new User(req.body.email, req.body.password);

  let existingUser;

  try {
    existingUser = await user.getUserWithSameEmail();
  } catch (error) {
    next(error);
  }

  const sessionErrorsData = {
    errorMessage:
      'Invalid credentials. Please double-check your email and password.',
    email: user.email,
    password: user.password,
  };

  if (!existingUser) {
    flashedSessionDataHandlerUtil.flashDataToSession(
      req,
      sessionErrorsData,
      () => {
        res.redirect('/login');
      }
    );
    return;
  }

  const passwordIsCorrect = await user.passwordIsCorrect(existingUser.password);

  if (!passwordIsCorrect) {
    flashedSessionDataHandlerUtil.flashDataToSession(
      req,
      sessionErrorsData,
      () => {
        res.redirect('/login');
      }
    );
    return;
  }

  userAuthSessionHandlerUtil.createUserAuthSession(
    req,
    existingUser,
    function () {
      res.redirect('/');
    }
  );
};

const logout = (req, res) => {
  userAuthSessionHandlerUtil.destroyUserAuthSession(req);
  res.redirect('/login');
};

module.exports = {
  login: login,
  getLogin: getLogin,
  signup: signup,
  getSignup: getSignup,
  logout: logout,
};
