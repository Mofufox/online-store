const path = require('path');

const express = require('express');
const expressSession = require('express-session');

const db = require('./data/db');

const generateCsrfTokenMiddleware = require('./middlewares/csrf-token-generator');
const addCsrfTokenToLocalsMiddleware = require('./middlewares/csrf-token-adder');
const handleErrorsMiddleware = require('./middlewares/errors-handler');
const checkAuthStatusMiddleware = require('./middlewares/auth-status-checker');

const createSessionConfig = require('./config/session');

const authRoutes = require('./routes/auth.routes');
const baseRoutes = require('./routes/base.routes');
const productsRoutes = require('./routes/products.routes');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static('public'));
app.use(express.urlencoded({ extended: false }));

const sessionConfig = createSessionConfig();
app.use(expressSession(sessionConfig));

app.use(generateCsrfTokenMiddleware);
app.use(addCsrfTokenToLocalsMiddleware);
app.use(checkAuthStatusMiddleware);

app.use(authRoutes);
app.use(baseRoutes);
app.use(productsRoutes);

app.use(handleErrorsMiddleware);

db.connectToDb()
  .then(() => {
    app.listen(3000);
    console.log('Successfully connected to the database!');
  })
  .catch((error) => {
    console.log(error);
    console.log('Failed to connect to the database!');
  });
